<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>footer_Get in touch Address SRS 110, Nasirp_fcb61c</name>
   <tag></tag>
   <elementGuidId>33fa47a6-b3c4-4244-ac46-1142fea93652</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>#colophon</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//footer[@id='colophon']</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>footer</value>
      <webElementGuid>6ffc4a45-40c8-455f-9361-b6f20a30da04</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>id</name>
      <type>Main</type>
      <value>colophon</value>
      <webElementGuid>029efd4c-6146-4696-b9c2-f177f4e03478</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>site-footer</value>
      <webElementGuid>7c611e39-2854-4626-9819-4559ba8eb359</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>role</name>
      <type>Main</type>
      <value>contentinfo</value>
      <webElementGuid>b552edd2-1d0b-43d3-9edb-5cd7be9386e5</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>
		

							
									
						
Get in touch
 Address :
SRS 110, Nasirpur Rd, near Palam, near Dwarka, Main Road, New Delhi, Delhi 110045

 E-mail id info@craferia.com 
 Call +91 8373915568 ,+91 9354367361					
											
						
INFORMATION


About Us 



Contact us 



Privacy Policy 



Term &amp; Condition

					
											
						
Useful Links


Blog 



Mudha Furnitures 



Corporate Gifts

					
											
						
Follow us

Facebook

Instagram

YouTube

Google

Pinterest
					
									
						
			© Handicrafts Online, Indian Handicraft Items, Handmade in India - Craferia 2024
							
				Built with Storefront &amp; WooCommerce.					
				
			
									
						My Account					
									
						Search			
				
	Search for:
	
	Search
	

			
								
									
															Cart				0
			
		
		
							
							
		
		
		
	</value>
      <webElementGuid>8ee4b93e-169b-4b7d-8b20-1ee8fbc0ad08</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;colophon&quot;)</value>
      <webElementGuid>8c2d3a5b-9524-4716-aa42-dbf64eb2bb64</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:attributes</name>
      <type>Main</type>
      <value>//footer[@id='colophon']</value>
      <webElementGuid>79974c2e-9cf7-47aa-ab6b-20deddf2a736</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//div[@id='page']/footer</value>
      <webElementGuid>80bb32e5-23c9-4364-af6e-9f4b12547dae</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//footer</value>
      <webElementGuid>253d949d-89b8-4429-9978-37dd9bb9b3b1</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//footer[@id = 'colophon' and (text() = '
		

							
									
						
Get in touch
 Address :
SRS 110, Nasirpur Rd, near Palam, near Dwarka, Main Road, New Delhi, Delhi 110045

 E-mail id info@craferia.com 
 Call +91 8373915568 ,+91 9354367361					
											
						
INFORMATION


About Us 



Contact us 



Privacy Policy 



Term &amp; Condition

					
											
						
Useful Links


Blog 



Mudha Furnitures 



Corporate Gifts

					
											
						
Follow us

Facebook

Instagram

YouTube

Google

Pinterest
					
									
						
			© Handicrafts Online, Indian Handicraft Items, Handmade in India - Craferia 2024
							
				Built with Storefront &amp; WooCommerce.					
				
			
									
						My Account					
									
						Search			
				
	Search for:
	
	Search
	

			
								
									
															Cart				0
			
		
		
							
							
		
		
		
	' or . = '
		

							
									
						
Get in touch
 Address :
SRS 110, Nasirpur Rd, near Palam, near Dwarka, Main Road, New Delhi, Delhi 110045

 E-mail id info@craferia.com 
 Call +91 8373915568 ,+91 9354367361					
											
						
INFORMATION


About Us 



Contact us 



Privacy Policy 



Term &amp; Condition

					
											
						
Useful Links


Blog 



Mudha Furnitures 



Corporate Gifts

					
											
						
Follow us

Facebook

Instagram

YouTube

Google

Pinterest
					
									
						
			© Handicrafts Online, Indian Handicraft Items, Handmade in India - Craferia 2024
							
				Built with Storefront &amp; WooCommerce.					
				
			
									
						My Account					
									
						Search			
				
	Search for:
	
	Search
	

			
								
									
															Cart				0
			
		
		
							
							
		
		
		
	')]</value>
      <webElementGuid>02c6e114-4b4b-4857-83db-470097403237</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
