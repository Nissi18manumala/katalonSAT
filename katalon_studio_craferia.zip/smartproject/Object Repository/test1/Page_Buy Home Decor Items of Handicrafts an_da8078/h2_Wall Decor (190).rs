<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>h2_Wall Decor (190)</name>
   <tag></tag>
   <elementGuidId>56aa144b-99f2-4c5d-a6ce-fa1ef2fd1315</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value></value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//main[@id='main']/ul/li[2]/a/h2</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>h2</value>
      <webElementGuid>83c9dbf9-0d9b-4cd0-b920-d7b6ed9a9bd6</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>woocommerce-loop-category__title</value>
      <webElementGuid>118aa75b-28b7-4b96-b29c-4644ebdb5735</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>
			Wall Decor (190)		</value>
      <webElementGuid>fd38da5f-fd00-4bd1-aba6-37f56f82c073</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;main&quot;)/ul[@class=&quot;products columns-4&quot;]/li[@class=&quot;product-category product&quot;]/a[1]/h2[@class=&quot;woocommerce-loop-category__title&quot;]</value>
      <webElementGuid>1b512386-76b8-441b-872a-f33122ab6bd2</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//main[@id='main']/ul/li[2]/a/h2</value>
      <webElementGuid>13d2cecb-a7dd-4f76-82a4-1aec4a54403c</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//li[2]/a/h2</value>
      <webElementGuid>c4dfb247-0efd-47be-89dd-4fb17586850b</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//h2[(text() = '
			Wall Decor (190)		' or . = '
			Wall Decor (190)		')]</value>
      <webElementGuid>85702612-50c8-452b-be62-df8257b34c45</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
