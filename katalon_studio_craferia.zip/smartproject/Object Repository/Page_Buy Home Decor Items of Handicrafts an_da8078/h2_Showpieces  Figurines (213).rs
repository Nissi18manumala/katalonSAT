<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>h2_Showpieces  Figurines (213)</name>
   <tag></tag>
   <elementGuidId>0ae37561-1d49-4d7e-827c-e4b5e5a3c239</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>h2.woocommerce-loop-category__title</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//main[@id='main']/ul/li/a/h2</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>h2</value>
      <webElementGuid>65e2e191-dbf5-4415-aba6-c19a93007572</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>woocommerce-loop-category__title</value>
      <webElementGuid>f1b3286e-2945-49f5-a0a8-d3226adb56e7</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>
			Showpieces &amp; Figurines (213)		</value>
      <webElementGuid>fde4747f-f3e6-4df0-ab49-5298b9283320</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;main&quot;)/ul[@class=&quot;products columns-4&quot;]/li[@class=&quot;product-category product first&quot;]/a[1]/h2[@class=&quot;woocommerce-loop-category__title&quot;]</value>
      <webElementGuid>ad20418f-4874-4b74-8a22-f64ef2a5f8f7</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//main[@id='main']/ul/li/a/h2</value>
      <webElementGuid>64498b30-83da-4f77-ad19-393641ed7349</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//h2</value>
      <webElementGuid>ea9390e5-b477-445f-987c-7a84e52f06ca</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//h2[(text() = '
			Showpieces &amp; Figurines (213)		' or . = '
			Showpieces &amp; Figurines (213)		')]</value>
      <webElementGuid>3bc5a536-bd98-4bb9-9f1e-a6641fb260e8</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
