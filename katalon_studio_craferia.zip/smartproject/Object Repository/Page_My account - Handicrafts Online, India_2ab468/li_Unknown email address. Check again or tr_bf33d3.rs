<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>li_Unknown email address. Check again or tr_bf33d3</name>
   <tag></tag>
   <elementGuidId>6adb3c9e-ddd2-4cbb-9d33-28682d51d667</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//div[@id='content']/div/div/ul/li</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value>ul.woocommerce-error > li</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>li</value>
      <webElementGuid>87552b02-d738-4d7b-aec7-63f46ea60f8f</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>
			Unknown email address. Check again or try your username.		</value>
      <webElementGuid>023b5c0d-e2ae-4d34-ad9d-a63859c15de4</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;content&quot;)/div[@class=&quot;col-full&quot;]/div[@class=&quot;woocommerce&quot;]/ul[@class=&quot;woocommerce-error&quot;]/li[1]</value>
      <webElementGuid>2a56dc09-3155-4d9e-8ce3-d3a76c21ca20</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//div[@id='content']/div/div/ul/li</value>
      <webElementGuid>4f6180f6-65b7-4fe9-8207-f8ec10948d3a</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//div[2]/div/div/ul/li</value>
      <webElementGuid>a4584c45-6ffe-4173-a829-321af1b2c9bb</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//li[(text() = '
			Unknown email address. Check again or try your username.		' or . = '
			Unknown email address. Check again or try your username.		')]</value>
      <webElementGuid>fe4e2960-e676-410b-9040-79d9174f3cb5</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
