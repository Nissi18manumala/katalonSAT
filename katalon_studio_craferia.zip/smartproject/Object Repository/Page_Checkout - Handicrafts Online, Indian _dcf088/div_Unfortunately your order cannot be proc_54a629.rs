<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>div_Unfortunately your order cannot be proc_54a629</name>
   <tag></tag>
   <elementGuidId>1765ba74-2625-4a97-90b7-4a92ac4ea44e</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//article[@id='post-8']/div/div/div</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value>div.woocommerce-order</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>div</value>
      <webElementGuid>0724dfd9-98aa-449f-9698-ecbdb1b8d92f</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>woocommerce-order</value>
      <webElementGuid>5bd9f548-6200-453b-a0c6-68869313461c</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>

	
		
            Unfortunately your order cannot be processed as the originating bank/merchant has declined your transaction. Please attempt your purchase again.

            
                Pay
				            
						
	
	Order details

	

		
			
				Product
				Total
			
		

		
			

	
		Bamboo Cane Chair Table Outdoor Furniture Set For Garden / Balcony × 1	

	
		₹4,950.00	



		

		
								
						Subtotal:
						₹4,950.00
					
										
						Shipping:
						₹150.00 via Box packing charges (NOTE : *Shipping charger will be calculation after courier partner discuss )
					
										
						Payment method:
						CCAvenue
					
										
						Total:
						₹5,100.00
					
										
	

	

	</value>
      <webElementGuid>0d2f241a-0fbf-4074-8b43-cdd35b589dbe</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;post-8&quot;)/div[@class=&quot;entry-content&quot;]/div[@class=&quot;woocommerce&quot;]/div[@class=&quot;woocommerce-order&quot;]</value>
      <webElementGuid>ce838fb7-88ee-445d-8623-909499acd03b</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//article[@id='post-8']/div/div/div</value>
      <webElementGuid>1a077c4d-c496-4c93-9772-7bc71834f998</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//article/div/div/div</value>
      <webElementGuid>b353faaf-19dd-4a68-bcd5-81ba20bbf569</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//div[(text() = '

	
		
            Unfortunately your order cannot be processed as the originating bank/merchant has declined your transaction. Please attempt your purchase again.

            
                Pay
				            
						
	
	Order details

	

		
			
				Product
				Total
			
		

		
			

	
		Bamboo Cane Chair Table Outdoor Furniture Set For Garden / Balcony × 1	

	
		₹4,950.00	



		

		
								
						Subtotal:
						₹4,950.00
					
										
						Shipping:
						₹150.00 via Box packing charges (NOTE : *Shipping charger will be calculation after courier partner discuss )
					
										
						Payment method:
						CCAvenue
					
										
						Total:
						₹5,100.00
					
										
	

	

	' or . = '

	
		
            Unfortunately your order cannot be processed as the originating bank/merchant has declined your transaction. Please attempt your purchase again.

            
                Pay
				            
						
	
	Order details

	

		
			
				Product
				Total
			
		

		
			

	
		Bamboo Cane Chair Table Outdoor Furniture Set For Garden / Balcony × 1	

	
		₹4,950.00	



		

		
								
						Subtotal:
						₹4,950.00
					
										
						Shipping:
						₹150.00 via Box packing charges (NOTE : *Shipping charger will be calculation after courier partner discuss )
					
										
						Payment method:
						CCAvenue
					
										
						Total:
						₹5,100.00
					
										
	

	

	')]</value>
      <webElementGuid>6daf210d-bf90-44ed-8b18-4d49e075b6be</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
