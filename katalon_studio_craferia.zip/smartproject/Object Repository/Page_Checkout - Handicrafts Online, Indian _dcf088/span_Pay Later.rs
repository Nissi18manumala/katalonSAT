<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>span_Pay Later</name>
   <tag></tag>
   <elementGuidId>3dc2b068-fa78-4fd8-8f90-943d1af40f97</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>(//div[@id='OPTPL']/span[2])[2]</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value>h2.resp-accordion.span12 > #OPTPL > span.innerpanel-text.innerpanel-bg.border.right-arrow.paymentOption</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>span</value>
      <webElementGuid>67ca6239-24d3-46ef-9ad1-f3d864f0e94d</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>innerpanel-text innerpanel-bg border right-arrow paymentOption</value>
      <webElementGuid>6475bdfe-a5ca-4e0f-9598-c20c6365aa95</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>Pay Later</value>
      <webElementGuid>07adb637-a941-4301-b934-0d5135dd6036</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;verticalTab&quot;)/div[@class=&quot;resp-tabs-container content-bg content-text border radius4 span9&quot;]/h2[@class=&quot;resp-accordion span12&quot;]/div[@id=&quot;OPTPL&quot;]/span[@class=&quot;innerpanel-text innerpanel-bg border right-arrow paymentOption&quot;]</value>
      <webElementGuid>1b6ec53a-22b1-41a7-b285-196a82224431</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>ref_element</name>
      <type>Main</type>
      <value>Object Repository/Page_Checkout - Handicrafts Online, Indian _dcf088/iframe_paymentFrame</value>
      <webElementGuid>ebff6211-0c71-4468-bba8-23ea4017ce2a</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>(//div[@id='OPTPL']/span[2])[2]</value>
      <webElementGuid>7f77d9ef-e022-4bc8-ad59-f152f177eb37</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//h2[7]/div/span[2]</value>
      <webElementGuid>6456b3f6-c64f-4e38-a87b-31e8df7197d5</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//span[(text() = 'Pay Later' or . = 'Pay Later')]</value>
      <webElementGuid>fc17e6f0-8b7f-45b2-8521-6925b56b4f13</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
