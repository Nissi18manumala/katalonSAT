<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>span_Card Number</name>
   <tag></tag>
   <elementGuidId>030efade-48bf-482f-b182-0086411806ca</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//div[@id='flexiPayOtpInit']/div[2]/div/div/span</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value>div.span12.flexipayDetails > div.span12.cards > span.span12.content-text.formText</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>span</value>
      <webElementGuid>2a7cb07a-d466-470d-b193-7f6b068f50ac</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>span12 content-text formText</value>
      <webElementGuid>41fce7f2-729b-4517-bd80-fb58a08bc31f</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>Card Number</value>
      <webElementGuid>4c42ac6e-9d41-4b6a-9245-8d10bc88dbfb</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;flexiPayOtpInit&quot;)/div[@class=&quot;span12 flexiPayCardDiv&quot;]/div[@class=&quot;span12 flexipayDetails&quot;]/div[@class=&quot;span12 cards&quot;]/span[@class=&quot;span12 content-text formText&quot;]</value>
      <webElementGuid>8dcb13f4-d90b-45b6-8739-1275b0e9da19</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>ref_element</name>
      <type>Main</type>
      <value>Object Repository/Page_Checkout - Handicrafts Online, Indian _dcf088/iframe_paymentFrame</value>
      <webElementGuid>3e645dbd-cec3-43f1-98cf-661d6b736ccd</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//div[@id='flexiPayOtpInit']/div[2]/div/div/span</value>
      <webElementGuid>051db36f-4e8a-4f7b-8ed8-bc1611741b89</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//div[6]/div[2]/div/div/span</value>
      <webElementGuid>9cafc912-347d-4e08-8380-2b1ab44b2c6c</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//span[(text() = 'Card Number' or . = 'Card Number')]</value>
      <webElementGuid>b5d585bb-b109-456e-8aca-9136d75afd28</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
